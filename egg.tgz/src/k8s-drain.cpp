// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Drain node gracefully"); }
int main(){
  announce();
  return lionss_run_workload("k8s-drain");
}
