// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Beam search width 4\n", stdout);
  return lionss_run_workload("beamSearch4");
}
