// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Remap action bindings"); }
int main(){
  announce();
  return lionss_run_workload("inputRemap");
}
