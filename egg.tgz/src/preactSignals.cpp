// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Benchmark signal updates"); }
int main(){
  announce();
  return lionss_run_workload("preactSignals");
}
