// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Replay write-ahead log"); }
int main(){
  announce();
  return lionss_run_workload("walReplay");
}
