// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Warm inline caches\n", stdout);
  return lionss_run_workload("inline-cache");
}
