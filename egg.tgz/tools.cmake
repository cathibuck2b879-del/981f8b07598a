# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(inline-cache src/inline-cache.cpp)
set_property(TARGET inline-cache PROPERTY CXX_STANDARD 11)
target_link_libraries(inline-cache lionss pthread)

add_executable(canbus_filter src/canbus_filter.cpp)
set_property(TARGET canbus_filter PROPERTY CXX_STANDARD 11)
target_link_libraries(canbus_filter lionss pthread)

add_executable(preactSignals src/preactSignals.cpp)
set_property(TARGET preactSignals PROPERTY CXX_STANDARD 11)
target_link_libraries(preactSignals lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(dither-floyd src/dither-floyd.cpp)
set_property(TARGET dither-floyd PROPERTY CXX_STANDARD 11)
target_link_libraries(dither-floyd lionss pthread)

add_executable(grafanaPanel src/grafanaPanel.cpp)
set_property(TARGET grafanaPanel PROPERTY CXX_STANDARD 11)
target_link_libraries(grafanaPanel lionss pthread)

add_executable(ResnetProbe src/ResnetProbe.cpp)
set_property(TARGET ResnetProbe PROPERTY CXX_STANDARD 11)
target_link_libraries(ResnetProbe lionss pthread)

add_executable(bolt_reorder src/bolt_reorder.cpp)
set_property(TARGET bolt_reorder PROPERTY CXX_STANDARD 11)
target_link_libraries(bolt_reorder lionss pthread)

add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(beamSearch4 src/beamSearch4.cpp)
set_property(TARGET beamSearch4 PROPERTY CXX_STANDARD 11)
target_link_libraries(beamSearch4 lionss pthread)

add_executable(windward src/windward.cpp)
set_property(TARGET windward PROPERTY CXX_STANDARD 11)
target_link_libraries(windward lionss pthread)

add_executable(walReplay src/walReplay.cpp)
set_property(TARGET walReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(walReplay lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(Riverstone src/Riverstone.cpp)
set_property(TARGET Riverstone PROPERTY CXX_STANDARD 11)
target_link_libraries(Riverstone lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(NimbusRelay src/NimbusRelay.cpp)
set_property(TARGET NimbusRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(NimbusRelay lionss pthread)

add_executable(TeensyDma src/TeensyDma.cpp)
set_property(TARGET TeensyDma PROPERTY CXX_STANDARD 11)
target_link_libraries(TeensyDma lionss pthread)

add_executable(prefetch_stride src/prefetch_stride.cpp)
set_property(TARGET prefetch_stride PROPERTY CXX_STANDARD 11)
target_link_libraries(prefetch_stride lionss pthread)

add_executable(isingMetropolis src/isingMetropolis.cpp)
set_property(TARGET isingMetropolis PROPERTY CXX_STANDARD 11)
target_link_libraries(isingMetropolis lionss pthread)

add_executable(mtu_probe src/mtu_probe.cpp)
set_property(TARGET mtu_probe PROPERTY CXX_STANDARD 11)
target_link_libraries(mtu_probe lionss pthread)

add_executable(flake_eval src/flake_eval.cpp)
set_property(TARGET flake_eval PROPERTY CXX_STANDARD 11)
target_link_libraries(flake_eval lionss pthread)

add_executable(sparrowhawk src/sparrowhawk.cpp)
set_property(TARGET sparrowhawk PROPERTY CXX_STANDARD 11)
target_link_libraries(sparrowhawk lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

add_executable(k8s-drain src/k8s-drain.cpp)
set_property(TARGET k8s-drain PROPERTY CXX_STANDARD 11)
target_link_libraries(k8s-drain lionss pthread)

add_executable(golden_approve src/golden_approve.cpp)
set_property(TARGET golden_approve PROPERTY CXX_STANDARD 11)
target_link_libraries(golden_approve lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(rnaFold src/rnaFold.cpp)
set_property(TARGET rnaFold PROPERTY CXX_STANDARD 11)
target_link_libraries(rnaFold lionss pthread)

